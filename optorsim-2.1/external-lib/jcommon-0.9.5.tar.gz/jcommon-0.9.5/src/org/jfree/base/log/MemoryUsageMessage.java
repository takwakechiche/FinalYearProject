package org.jfree.base.log;

/**
 * A helper class to print memory usage message if needed.
 */
public class MemoryUsageMessage
{
  /** The message. */
  private final String message;

  /**
   * Creates a new message.
   *
   * @param message  the message.
   */
  public MemoryUsageMessage(final String message)
  {
    this.message = message;
  }

  /**
   * Returns a string representation of the message (useful for debugging).
   *
   * @return the string.
   */
  public String toString()
  {
    return (message
        + "Free: " + Runtime.getRuntime().freeMemory() + "; "
        + "Total: " + Runtime.getRuntime().totalMemory());
  }
}
