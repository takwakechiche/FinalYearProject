package org.jfree.base.log;

import java.util.Arrays;

/**
 * A message object that pads the output if the text is shorted than the given length.
 */
public class PadMessage
{
  /**
   * The message.
   */
  private final Object text;
  /**
   * The padding size.
   */
  private final int length;

  /**
   * Creates a new message.
   *
   * @param message the message.
   * @param length  the padding size.
   */
  public PadMessage (final Object message, final int length)
  {
    this.text = message;
    this.length = length;
  }

  /**
   * Returns a string representation of the message.
   *
   * @return the string.
   */
  public String toString ()
  {
    final StringBuffer b = new StringBuffer();
    b.append(text);
    if (b.length() < length)
    {
      final char[] pad = new char[length - b.length()];
      Arrays.fill(pad, ' ');
      b.append(pad);
    }
    return b.toString();
  }
}
